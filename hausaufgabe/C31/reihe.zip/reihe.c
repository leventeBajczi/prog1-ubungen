/*Die folgende Reihe

1 / (3 * 5) + 1 / (7 * 9) + 1 / (11 * 13) + ... + 1 / ((4n - 1) * (4n + 1))

strebt gegen einen bestimmten Wert. Berechnen Sie diesen Wert mit einer Genauigkeit von 10-12,
also die Berechnung ist dann abzubrechen, wenn der Unterschied der letzten zwei Summen kleiner
als der Grenzwert ist. Wenden Sie das nachfolgende Programm an:*/

#include <stdio.h>
#define GRENZWERT 1E-12


int main() {
    int n = 0;
    float sum = 0.0f;
    do{
        n++;
        sum+=(float)1.0 / (float)((4*n-1)*(4*n+1));
    }
    while((float)1.0 / (float)((4*n-1)*(4*n+1)) >= GRENZWERT);
	printf("%3.12f", sum);
	return 0;

}